A live environment can be accessed in-browser here: https://hub.mybinder.org/user/stack-attack-ap-achine-learning-9q17u46e/tree/Assignment%203.

Coding was done in a Jupyter notebook on Python 3.