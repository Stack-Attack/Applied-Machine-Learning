
# coding: utf-8

# # Question 4.2

# In[1]:


import numpy as np
import pandas as pd
import scipy as sp
import math
from sklearn.utils import shuffle
from sklearn.svm import SVC
from random import randint
from sklearn.model_selection import KFold, cross_validate, cross_val_score, cross_val_predict, GridSearchCV
from sklearn.metrics import confusion_matrix, classification_report
from collections import OrderedDict


# In[2]:


#Headers sets names for all of the attributes contained in the data set
headers = ["a1",
           "a2",
           "a3",
           "a4",
           "a5",
           "a6",
           "a7",
           "a8",
           "a9",
           "a10",
           "a11",
           "a12",
           "a13",
           "a14",
           "a15",
           "a16",
           "a17",
           "a18",
           "a19",
           "a20",
           "a21",
           "a22",
           "a23",
           "a24",
           "a25",
           "a26",
           "a27",
           "a28",
           "a29",
           "a30",
           "a31",
           "a32",
           "a33",
           "a34",
           "label"]
                
#Data is read into pandas dataframe
data = pd.read_csv("ionosphere.csv", names = headers)
data = data.reset_index(drop=True)

#Transform the labels into binary values
def binarize(val):
    if val == 'g':
        return 1
    else:
        return 0
data['label'] = data['label'].map(binarize)

data.head(5)


# 
# # SVM Kernels
# ## Train and Test on Same Data

# ### Linear

# In[26]:


data.shape[1]-1


# In[3]:


#Create rbf SVM Classifier with deafault values
svm = l_svm = SVC(kernel='linear')

#Initialize a series of Ordered Dictionaries to store scores
l_c=OrderedDict()
l_gamma=OrderedDict()
l_degree=OrderedDict()

#Work through c-values
for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    l_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #l_c[key]=np.average(scores)
    
#Reset C to default
svm.set_params(C=1)

for key in range(1,100):
    svm.set_params(degree=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    l_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #l_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    l_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #l_gamma[key]=np.average(scores)


# ### Polynomial

# In[4]:


#Create rbf SVM Classifier with deafault values
svm = SVC(kernel='poly', gamma='scale')

#Initialize a series of Ordered Dictionaries to store scores
p_c=OrderedDict()
p_gamma=OrderedDict()
p_degree=OrderedDict()

for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    p_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #p_c[key]=np.average(scores)

#Reset C to default
svm.set_params(C=1)
    
for key in range(1,100):
    svm.set_params(degree=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    p_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #p_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    p_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #p_gamma[key]=np.average(scores)



# ### Radial Basis

# In[5]:


#Create rbf SVM Classifier with deafault values
svm = SVC(kernel='rbf', gamma='scale')

#Initialize a series of Ordered Dictionaries to store scores
r_c=OrderedDict()
r_gamma=OrderedDict()
r_degree=OrderedDict()

for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
    
    svm.fit(data.iloc[:,:34], data["label"])
    r_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #r_c[key]=np.average(scores)

#Reset C to default
svm.set_params(C=1)
    
for key in range(1,100):
    svm.set_params(degree=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    r_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #r_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    svm.fit(data.iloc[:,:34], data["label"])
    r_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    #scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    #r_gamma[key]=np.average(scores)


# In[6]:


#Combine data into dataframe
c_data = pd.DataFrame.from_dict([l_c,p_c,r_c],).set_index([['Linear','Polynomial','Radial']])
c_data


# In[7]:


#Combine data into dataframe
gamma_data = pd.DataFrame.from_dict([l_gamma,p_gamma,r_gamma]).set_index([['Linear','Polynomial','Radial']])
gamma_data


# In[8]:


#Combine data into dataframe
degree_data = pd.DataFrame.from_dict([l_degree,p_degree,r_degree]).set_index([['Linear','Polynomial','Radial']])
degree_data


# In[9]:


results = c_data.T

#Plot the results
plot = results.plot.line(title='Training SVM Kernal Performance Over Varying C Values')
plot.set_xlabel("C")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_c_t.pdf")

results = degree_data.T
#Plot the results
plot = results.plot.line(title='Training SVM Kernal Performance Over Varying Degree Values')
plot.set_xlabel("Degree")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_degree_t.pdf")

results = gamma_data.T
#Plot the results
plot = results.plot.line(title='Training SVM Kernal Performance Over Varying Gamma Values')
plot.set_xlabel("Gamma")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_gamma_t.pdf")


# ## 10-Fold Validation
# ### Linear

# In[10]:


#Create rbf SVM Classifier with deafault values
svm = l_svm = SVC(kernel='linear')

#Initialize a series of Ordered Dictionaries to store scores
l_c=OrderedDict()
l_gamma=OrderedDict()
l_degree=OrderedDict()

#Work through c-values
for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #l_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    l_c[key]=np.average(scores)
    
#Reset C to default
svm.set_params(C=1)

for key in range(1,100):
    svm.set_params(degree=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #l_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    l_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #l_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    l_gamma[key]=np.average(scores)



# ### Polynomial

# In[11]:


#Create rbf SVM Classifier with deafault values
svm = SVC(kernel='poly', gamma='scale')

#Initialize a series of Ordered Dictionaries to store scores
p_c=OrderedDict()
p_gamma=OrderedDict()
p_degree=OrderedDict()

for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #p_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    p_c[key]=np.average(scores)

#Reset C to default
svm.set_params(C=1)
    
for key in range(1,100):
    svm.set_params(degree=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #p_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    p_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #p_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    p_gamma[key]=np.average(scores)


# ### Radial Basis

# In[12]:


#Create rbf SVM Classifier with deafault values
svm = SVC(kernel='rbf', gamma='scale')

#Initialize a series of Ordered Dictionaries to store scores
r_c=OrderedDict()
r_gamma=OrderedDict()
r_degree=OrderedDict()

for key in np.geomspace(0.01,1000,num=100):
    svm.set_params(C=key)
    
    #svm.fit(data.iloc[:,:34], data["label"])
    #r_c[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    r_c[key]=np.average(scores)

#Reset C to default
svm.set_params(C=1)
    
for key in range(1,100):
    svm.set_params(degree=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #r_degree[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    r_degree[key]=np.average(scores)
    
#Reset degree to default
svm.set_params(degree=3)    
    
for key in np.geomspace(0.01,100,num=100):
    svm.set_params(gamma=key)
        
    #svm.fit(data.iloc[:,:34], data["label"])
    #r_gamma[key] = svm.score(data.iloc[:,:34], data["label"])
    
    scores = cross_val_score(svm, data.iloc[:,:34], data["label"], cv=10)
    r_gamma[key]=np.average(scores)


# In[13]:


#Combine data into dataframe
c_data = pd.DataFrame.from_dict([l_c,p_c,r_c],).set_index([['Linear','Polynomial','Radial']])
c_data


# In[14]:


#Combine data into dataframe
gamma_data = pd.DataFrame.from_dict([l_gamma,p_gamma,r_gamma]).set_index([['Linear','Polynomial','Radial']])
gamma_data


# In[15]:


#Combine data into dataframe
degree_data = pd.DataFrame.from_dict([l_degree,p_degree,r_degree]).set_index([['Linear','Polynomial','Radial']])
degree_data


# In[16]:


results = c_data.T

#Plot the results
plot = results.plot.line(title='10-Fold SVM Kernal Performance Over Varying C Values')
plot.set_xlabel("C")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_c_10.pdf")

results = degree_data.T
#Plot the results
plot = results.plot.line(title='10-Fold SVM Kernal Performance Over Varying Degree Values')
plot.set_xlabel("Degree")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_degree_10.pdf")

results = gamma_data.T
#Plot the results
plot = results.plot.line(title='10-Fold SVM Kernal Performance Over Varying Gamma Values')
plot.set_xlabel("Gamma")
plot.set_ylabel("Accuracy")
plot.set_xscale("log")
#Display plot in Jupyter
plot
fig = plot.get_figure()
fig.savefig("Q4_gamma_10.pdf")


